import edu.princeton.cs.algs4.MinPQ;

/**
 *  First, insert the initial search node (the initial board, 0 moves, and a null previous search node) into a priority queue. Then, delete from the priority queue the search node with the minimum priority, and insert onto the priority queue all neighboring search nodes (those that can be reached in one move from the dequeued search node). Repeat this procedure until the search node dequeued corresponds to a goal board. The success of this approach hinges on the choice of priority function for a search node. We consider two priority functions:
 * @author alex
 *
 */
public class Solver {
	
	SolverImpl si;
	
    public Solver(Board initial)           // find a solution to the initial board (using the A* algorithm)
    {
    	si = new SolverImpl( initial );
    	
    	while( si.hasNext() ){
    		si.next();
    	}
    	
    }
    
    public boolean isSolvable()            // is the initial board solvable?
    {
    	return this.si.solved;
    }
    
    public int moves()                     // min number of moves to solve initial board; -1 if unsolvable
    {
    	return this.si.currentNode.moves;
    }
    
    public Iterable<Board> solution()      // sequence of boards in a shortest solution; null if unsolvable
    {
    	return null;
    }
	
	// --------------------------------------------------------------------------------------------------------------------------------------
	
	
	/** 
	 *  First, insert the initial search node (the initial board, 0 moves, and a null previous search node) into a priority queue.
	 *  
	 */
	class SolverImpl {
		
		MinPQ<SearchNode> minQ;
		boolean solved = false;
		SearchNode currentNode;
		
		
		boolean _verbose = true;
		int _step = 0;
		
		SolverImpl( Board initialBoard ) {
			
			SearchNode initNode = new SearchNode( initialBoard, 0, null );
			
			minQ = new MinPQ<SearchNode>();
			minQ.insert(initNode);
			
			currentNode = initNode;
		}
		/**
		 * 
		 *   Then, delete from the priority queue the search node with the minimum priority, 
		 *   and insert onto the priority queue all neighboring search nodes
		 *    (those that can be reached in one move from the dequeued search node).
		 *    
		 */
		void next() {
			
			/**
			 * Step 0:    priority  = 4
           moves     = 0
           manhattan = 4
           3            
            0  1  3     
            4  2  5     
            7  8  6  
			 */
			
			printStep();
			
			
			SearchNode prevNode = this.currentNode;
			this.currentNode = minQ.delMin();
			
			
			if (this.currentNode.b.isGoal()) {
				this.solved = true;
				return;
			}
			
			for( Board nb : this.currentNode.b.neighbors() ) {
				if ( nb.equals( prevNode.b )) continue; 	
				minQ.insert( new SearchNode( nb, this.currentNode.moves+1, prevNode ));
			}
			
			_step++;
			
		}
		
		private void printStep() {
			
			if (! this._verbose )
					return ;
			
			System.out.println( "Step: " + _step + " priority  = " + this.currentNode.score() );
			System.out.println( "\tmoves     = " + this.currentNode.moves );
			System.out.println( "\tmanhattan = " + this.currentNode.b.manhattan() );
			System.out.println( "\t" + this.currentNode.b );
		}
		
		/**
		 *  Repeat this procedure until the search node dequeued corresponds to a goal board.
		 */
		boolean hasNext() {
			return ! ( this.solved || minQ.isEmpty() );
		}
		
	}

	/**
	 *  We define a search node of the game to be:
	 * 	a board, 
	 *  the number of moves made to reach the board, 
	 *  and the previous search node. 
 	 */
	class SearchNode implements Comparable<SearchNode> {
		
		Board b;
		int moves;
		SearchNode prev;
		
		SearchNode( Board b, int moves, SearchNode prev) {
			this.b = b;
			this.moves = moves;
			this.prev = prev;
		}
		
		private int score() {
			return this.b.manhattan() + this.moves;
		}

		@Override
		public int compareTo(SearchNode o) {
			return this.score() - o.score();
		}
		
	}
}
